### Student-Management-System



### Requirements
- <strong>Python3 + </strong>

### Installation & Running
<pre>
git clone https://github.com/thetechnohack/Student-Management-System/

cd Student-Management-System

pip3 install -r requirements.txt

python3 main.py
</pre>
<hr>
